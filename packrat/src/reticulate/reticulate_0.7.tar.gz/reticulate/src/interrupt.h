
#ifndef __PYTHON_INTERRUPT__
#define __PYTHON_INTERRUPT__

void initialize_interrupt_polling();

#endif // __PYTHON_INTERRUPT__
