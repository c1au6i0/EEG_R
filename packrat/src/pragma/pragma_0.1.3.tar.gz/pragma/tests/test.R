
library(pragma)
# source( "../../last.call/R/last.call.R" )
    
setPragma( "KEYWORD", function() cat("It works.") )
KEYWORD

